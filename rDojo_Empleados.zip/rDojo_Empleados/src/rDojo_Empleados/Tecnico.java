package rDojo_Empleados;

import utilidades.Leer;

public class Tecnico {
	private String especialidad;
	private Float plusEspecialidad;
	private Responsable jefe;

	public Float calculoNomina() {
		return;
	}
}